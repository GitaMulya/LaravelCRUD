<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class mahasiswa1 extends Model
{
    protected $table ='students';
    use HasFactory;
}
