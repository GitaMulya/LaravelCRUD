@extends('layout/main')

@section('judul', 'Data Mahasiswa')

@section('container')
  <div class="container">
    <div class="row">
      <h1 class="mt-3">Selamat Datang!</h1>
      <h4>Untuk mengelola data mahasiswa silakan kunjungi halaman Mahasiswa</h4>    
      <h4>Untuk melihat daftar dan detail data mahasiswa silakan kunjungi halaman Detail</h4> 
    </div>
  </div>
@endsection


   