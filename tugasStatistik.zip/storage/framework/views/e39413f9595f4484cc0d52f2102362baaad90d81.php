

<?php $__env->startSection('judul', 'About'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container-fluid">
    <div class="row">
      <h1 class="mt-3">Hello, <?php echo e($nama); ?>!</h1>    
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasStatistik\resources\views/about.blade.php ENDPATH**/ ?>