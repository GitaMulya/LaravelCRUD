

<?php $__env->startSection('judul', 'Data Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
      <h1 class="mt-2">Data Mahasiswa Ilkom</h1>
      <a href="/mahasiswa/create" class="btn btn-outline-primary col-2 mt-3 mb-2 ms-3">Tambah Data</a>
        <?php if(session('status')): ?>
            <div class="alert alert-success ms-3">
              <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>    
      <table class="table table-striped table-bordered table-hover mt-2 ms-3">
        <thead class="table-white"> 
            <tr>
                <th scope="col">No</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Kelas</th>
                <th scope="col">Nilai</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
       
        <tbody>

            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td scope="row"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($mhs->NIM); ?></td>
                <td><?php echo e($mhs->Nama); ?></td>
                <td><?php echo e($mhs->Kelas); ?></td>
                <td><?php echo e($mhs->Nilai); ?></td>
                <td>
                    <a href="/mahasiswa/<?php echo e($mhs->id); ?>/edit" class="btn btn-outline-success btn-sm">Edit</a>
                    <a href="/mahasiswa/<?php echo e($mhs->id); ?>/delete" class="btn btn-outline-danger btn-sm">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="col-4 mt-4">
        <h5>Tabel Frekuensi</h5>
            <table class="table table-striped table-bordered table-hover mt-2">
              <thead>
                <tr>
                  <td scope="col"><b>Nilai</b></td>
                  <td scope="col"><b>Frekuensi</b></td>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $frekuensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                 
                  <tr>
                    <td> <?php echo e($Nilai->Nilai); ?> </td>
                    <td> <?php echo e($Nilai->frekuensi); ?></td>
                  </tr>                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td> <b>Total Nilai:</b>  </td>
                    <td> <?php echo e($totalNilai); ?></td>
                  </tr>
                  <tr>
                    <td> <b>Total Frekuensi:</b>  </td>
                    <td> <?php echo e($totalfrekuensi); ?></td>
                  </tr>
              </tbody>
           </table>
      </div>
      <div class="col-4 mt-4 ms-4">
        <h5>Tabel Min, Max, dan Rata-rata Nilai</h5>
            <table class="table table-striped table-bordered table-hover mt-2">
              <thead>
                <tr>
                  <td scope="col"><b>Nilai Max</b></td>
                  <td scope="col"><b>Nilai Min</b></td>
                  <td scope="col"><b>Nilai Rata-rata</b></td>
                </tr>
              </thead>
              <tbody>               
                  <tr>
                    <td> <label for="max" class="ml-4"><?php echo e($max); ?></label> </td>
                    <td><label for="min" class="ml-4"><?php echo e($min); ?></label></td>
                    <td><label for="rata2" class="ml-4"><?php echo e($rata2); ?></label></td>
                  </tr>                  
              </tbody>
           </table>
      </div>     
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasStatistik\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>