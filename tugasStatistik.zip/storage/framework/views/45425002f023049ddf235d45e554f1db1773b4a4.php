

<?php $__env->startSection('judul', 'Data Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
      <h1 class="mt-3">Selamat Datang!</h1>
      <h4>Untuk mengelola data mahasiswa silakan kunjungi halaman Mahasiswa</h4>    
      <h4>Untuk melihat daftar dan detail data mahasiswa silakan kunjungi halaman Detail</h4> 
    </div>
  </div>
<?php $__env->stopSection(); ?>


   
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasStatistik\resources\views/index.blade.php ENDPATH**/ ?>