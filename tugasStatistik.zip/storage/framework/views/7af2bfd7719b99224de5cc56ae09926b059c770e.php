

<?php $__env->startSection('judul', 'Detail Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
     <div class="col-7">
      <h1 class="mt-3">Detail Mahasiswa Ilkom</h1> 
      <div class="card">
            <div class="card-body">
                <h5 class="card-title mb-3"><?php echo e($student->Nama); ?></h5>
                <p class="card-subtitle mb-2 text-muted"><?php echo e($student->NIM); ?></p>
                <p class="card-text"><?php echo e($student->Kelas); ?></p>
                <p class="card-text"><?php echo e($student->Nilai); ?></p>
                <a href="<?php echo e($student->id); ?>/edit" class="btn btn-outline-success btn-sm">Edit</a>
                <form action="/students/<?php echo e($student->id); ?>" method="post" class="d-inline">
                 <?php echo method_field('delete'); ?>
                 <?php echo csrf_field(); ?> 
                 <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                </form>
                <a href="/students" class="btn btn-outline-secondary btn-sm">Kembali</a>
            </div>
      </div>
     </div>      
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasStatistik\resources\views/students/show.blade.php ENDPATH**/ ?>